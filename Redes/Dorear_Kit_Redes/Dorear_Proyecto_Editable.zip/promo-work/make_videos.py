from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageOps
from pathlib import Path
import json,math,subprocess,concurrent.futures,os,numpy as np,wave
ROOT=Path(__file__).resolve().parent;OUT=ROOT.parent/'deliverables';OUT.mkdir(exist_ok=True)
W,H=1080,1920
CREAM='#faf7f0';WINE='#672d35';INK='#372e25';GOLD='#a67c3f';MUTED='#837568'
assets=json.loads((ROOT/'assets.json').read_text());caps=json.loads((ROOT/'captures.json').read_text())
fontpaths={}
for u,f in assets.items():
 if 'co3um' in u:fontpaths['serif']=ROOT.parent/f
 if 'xhTg.ttf' in u:fontpaths['sans']=ROOT.parent/f
# Explicit font weights, matching the app's own assets.
fontpaths['serif']=ROOT.parent/[f for u,f in assets.items() if 'OD_iE9GnM' in u][0]
fontpaths['sans']=ROOT.parent/[f for u,f in assets.items() if 'EwAopxhTg' in u][0]
fontpaths['bold']=ROOT.parent/[f for u,f in assets.items() if 'EwARZthTg' in u][0]
def font(size,kind='sans'):return ImageFont.truetype(str(fontpaths[kind]),size)
def wrap(d,text,f,maxw):
 lines=[]
 for para in text.split('\n'):
  line=''
  for word in para.split():
   trial=(line+' '+word).strip()
   if line and d.textlength(trial,font=f)>maxw:lines.append(line);line=word
   else:line=trial
  lines.append(line)
 return lines

def text_center(d,text,y,size=40,kind='sans',fill=INK,maxw=940,spacing=1.12):
 f=font(size,kind);lines=wrap(d,text,f,maxw)
 for i,line in enumerate(lines):
  d.text(((W-d.textlength(line,font=f))/2,y+i*size*spacing),line,font=f,fill=fill)
 return y+len(lines)*size*spacing

def tracked(d,text,y,size=25,color=GOLD,tracking=6):
 f=font(size,'sans');tw=sum(d.textlength(c,font=f) for c in text)+tracking*(len(text)-1);x=(W-tw)/2
 for c in text:d.text((x,y),c,font=f,fill=color);x+=d.textlength(c,font=f)+tracking

def base():
 im=Image.new('RGB',(W,H),CREAM);d=ImageDraw.Draw(im)
 # Quiet editorial background and a gold rule.
 d.arc((-520,820,1620,2820),185,355,fill='#eee4d7',width=2)
 d.arc((-180,-820,1700,1020),30,155,fill='#eee4d7',width=2)
 return im

def phone(im,name,highlight=True):
 # Rounded device with the original app screenshot, never a redrawn UI.
 screen=Image.open(ROOT/caps[name]['file']).convert('RGB').resize((772,1293),Image.Resampling.LANCZOS)
 x,y=154,395
 shadow=Image.new('RGBA',(W,H));sd=ImageDraw.Draw(shadow);sd.rounded_rectangle((124,338,956,1739),radius=74,fill=(55,46,37,50));shadow=shadow.filter(ImageFilter.GaussianBlur(29));im.paste(shadow,(0,0),shadow)
 d=ImageDraw.Draw(im);d.rounded_rectangle((134,337,946,1732),radius=65,fill='#372e25');d.rounded_rectangle((141,344,939,1725),radius=58,fill='#f4eee3',outline='#b89b75',width=2)
 d.text((177,355),'9:41',font=font(21,'bold'),fill=INK)
 # Neutral status glyphs.
 for i in range(4):d.rounded_rectangle((831+i*7,371-i*3,835+i*7,378),radius=1,fill=INK)
 d.rounded_rectangle((872,360,902,375),radius=3,outline=INK,width=2);d.rectangle((902,364,905,371),fill=INK)
 mask=Image.new('L',screen.size,0);ImageDraw.Draw(mask).rounded_rectangle((0,0,771,1292),radius=25,fill=255);im.paste(screen,(x,y),mask)
 d=ImageDraw.Draw(im);d.rounded_rectangle((439,1705,641,1713),radius=4,fill=INK)
 f=caps[name].get('focus')
 if highlight and f:
  scale=772/430;left=x+f['x']*scale;top=y+f['y']*scale;right=left+f['w']*scale;bottom=top+f['h']*scale
  if top>y and bottom<y+1293 and bottom-top<230:
   d.rounded_rectangle((left-5,top-5,right+5,bottom+5),radius=18,outline=GOLD,width=5)
   # A touch marker next to the selected element.
   cx=min(909,right-9);cy=max(y+15,top+13)
   d.ellipse((cx-14,cy-14,cx+14,cy+14),fill=CREAM,outline=GOLD,width=4)
   d.ellipse((cx-5,cy-5,cx+5,cy+5),fill=GOLD)

def card(shot,title,note,section,idx,total):
 im=base();d=ImageDraw.Draw(im);tracked(d,'D O R E A R',65,31,tracking=5)
 d.line((78,120,1002,120),fill='#dfcfb9',width=2)
 d.text((80,143),section.upper(),font=font(23,'bold'),fill=GOLD)
 d.text((1000-d.textlength(f'{idx:02d} / {total:02d}',font=font(23)),143),f'{idx:02d} / {total:02d}',font=font(23),fill=MUTED)
 text_center(d,title,190,78,'serif',maxw=950,spacing=.98)
 phone(im,shot)
 d=ImageDraw.Draw(im);text_center(d,note,1770,34,maxw=940,spacing=1.18)
 d.line((80,1880,1000,1880),fill='#dfcfb9',width=4)
 d.line((80,1880,80+920*idx/total,1880),fill=GOLD,width=5)
 return im

def intro(kind='reel'):
 im=base();d=ImageDraw.Draw(im)
 # Two authentic interface cards, stacked as a product mockup.
 for name,box,angle in [('cakes',(40,540,500,1310),-10),('coffee_after',(530,630,990,1400),9)]:
  s=Image.open(ROOT/caps[name]['file']).convert('RGB');s.thumbnail((480,805));m=Image.new('L',s.size,0);ImageDraw.Draw(m).rounded_rectangle((0,0,s.width-1,s.height-1),radius=24,fill=255);rgba=s.convert('RGBA');rgba.putalpha(m);rgba=rgba.rotate(angle,expand=True,resample=Image.Resampling.BICUBIC);im.paste(rgba,(box[0],box[1]),rgba)
 d=ImageDraw.Draw(im);tracked(d,'PUERTO MADERO',100,27,tracking=7)
 text_center(d,'DOREAR',170,133,'serif',GOLD)
 text_center(d,'Tu ratito.\nTambién en tu celular.',340,79,'serif',spacing=.98)
 d.rounded_rectangle((116,1510,964,1707),radius=30,fill=WINE)
 label={'reel':'Descubrí nuestra carta digital','tutorial':'Así se usa nuestra carta','staff':'Guía para el equipo'}[kind]
 text_center(d,label,1540,47,'serif',CREAM,maxw=800)
 text_center(d,'Sin descargar una app' if kind!='staff' else 'Barra y administración',1624,29,fill='#efe0c9')
 text_center(d,'@dorearcafe.ar',1800,30,fill=GOLD)
 return im

def outro(kind='reel'):
 im=Image.new('RGB',(W,H),WINE);d=ImageDraw.Draw(im)
 d.arc((-300,660,1380,2340),180,360,fill='#835057',width=2)
 tracked(d,'DOREAR',170,53,color='#dac19b',tracking=20)
 text_center(d,'Que espere todo,\neste ratito es tuyo.',365,105,'serif',CREAM,spacing=1.02)
 d.line((210,710,870,710),fill='#a7786d',width=2)
 if kind=='staff':
  text_center(d,'Una carta al día.\nUn equipo conectado.',850,76,'serif',CREAM)
  text_center(d,'Demo local · Accesos de ejemplo\nRestauración realizada al finalizar',1130,32,fill='#eadcc8',spacing=1.5)
 else:
  text_center(d,'Escaneá el QR del local\ny descubrí qué te tienta hoy.',840,55,'serif',CREAM,spacing=1.15)
  d.rounded_rectangle((200,1080,880,1180),radius=50,fill=CREAM)
  text_center(d,'@dorearcafe.ar',1106,37,'bold',WINE)
  text_center(d,'Rosario Vera Peñaloza 460\nPuerto Madero · CABA',1280,36,fill='#eadcc8',spacing=1.5)
 text_center(d,'Pastelería de autor · Café de especialidad',1710,30,fill='#dac19b')
 text_center(d,'Fotos y precios ilustrativos de la versión revisada.',1810,22,fill='#dac19b')
 return im

# shot, title, on-screen instruction, seconds
reel=[
 ('INTRO','', '',4),
 ('home','La carta, en tu celular.','Abrila desde el QR del local. Sin descargas.',3),
 ('cakes','¿Qué te tienta hoy?','Explorá cafés, pastelería, brunch y más.',4),
 ('coffee_after','Tu café, a tu manera.','Elegí un adicional y mirá el precio actualizado.',4),
 ('gluten','Encontrá tus opciones.','Filtrá la carta. Consultanos por alergias.',3),
 ('english','En tu idioma.','Español · English · Português',2),
 ('portuguese','No seu idioma.','Cambiá el idioma con un toque.',2),
 ('weekly','Un almuerzo diferente.','Descubrí el menú ejecutivo de la semana.',4),
 ('pickup','¿Lo querés para llevar?','Coordiná tu pedido por WhatsApp.',4),
 ('reserve_form','Un ratito para compartir.','Solicitá tu mesa para grupos de 5 a 16.',5),
 ('wifi_copied','Conectate y disfrutá.','Los datos del Wi-Fi, a un toque.',3),
 ('OUTRO','', '',7)]
tutorial=[
 ('INTRO','','',4),
 ('home','Abrí la carta.','Escaneá el QR del local con tu celular.',6),
 ('english','Elegí tu idioma.','Tocá EN para ver la carta en inglés.',3),
 ('portuguese','También en portugués.','Tocá PT. Podés volver a ES cuando quieras.',3),
 ('cakes','Explorá las categorías.','Deslizá la barra y tocá lo que querés ver.',6),
 ('cake_detail','Conocé cada producto.','Tocá su nombre para abrir el detalle y la foto.',6),
 ('gluten','Usá los filtros.','Sin TACC filtra la categoría que estás mirando.',6),
 ('vegan','Opciones veganas.','Tocá Vegano para ver las opciones etiquetadas.',3),
 ('dairyfree','Opciones sin lactosa.','Cada filtro se aplica a la categoría activa.',3),
 ('coffee_before','Elegí un adicional.','En el detalle podés elegir hasta una opción.',4),
 ('coffee_after','Revisá el total.','El precio cambia y se muestran advertencias.',6),
 ('weekly','Mirá toda la semana.','Abrí el menú ejecutivo y elegí un día.',6),
 ('weekly_dinein','¿Salón o Take Away?','Abrí el plato para ver las modalidades.',4),
 ('weekly_takeaway','Para retirar.','Tocá Take Away y revisá el precio de esa opción.',5),
 ('cake_order','Encargá una torta.','En Tortas y Budines, tocá Consultar Torta.',7),
 ('pickup','Pedí por WhatsApp.','Tocá Pedir para llevar y coordiná con el local.',7),
 ('reserve_form','Organizá tu encuentro.','Elegí personas, fecha, horario y tus datos.',9),
 ('reserve_deposit','Revisá la propuesta.','Leé el menú fijo y las instrucciones de la seña.',7),
 ('reserve_send','Enviá la solicitud.','Sumá notas o torta. El local confirma por WhatsApp.',8),
 ('wifi','Abrí el Wi-Fi.','Tocá Wi-Fi en la cabecera para ver los datos.',4),
 ('wifi_copied','Copiá la clave.','Tocá Copiar clave y pegala al conectarte.',3),
 ('review','Contanos tu experiencia.','El botón de reseñas abre Google.',5),
 ('location','Encontranos y seguinos.','Consultá horarios, abrí Maps o visitá Instagram.',5),
 ('offline','Si perdés la señal.','Con la carta abierta, se indica el modo sin señal.',4),
 ('OUTRO','','',4)]
staff=[
 ('INTRO','','',4),
 ('staff_login','Ingresá con tu acceso.','El PIN define el rol: barra o administración.',6),
 ('barista','Control de barra.','Consultá productos y disponibilidad.',5),
 ('barista_search','Encontrá el producto.','Buscá por nombre o filtrá por categoría.',5),
 ('barista_soldout','Marcá lo agotado.','Un toque cambia Disponible a Agotado.',6),
 ('customer_soldout','Así lo ve el cliente.','El estado se refleja en la carta sincronizada.',5),
 ('admin','Gestión del local.','El acceso de administración abre más controles.',5),
 ('admin_weekly','Editá el menú semanal.','Cambiá textos, traducciones, foto y precios.',6),
 ('admin_override','Elegí el plato destacado.','Usá el calendario o fijá un día manualmente.',5),
 ('admin_items','Administrá la carta.','Navegá por categorías o creá un nuevo plato.',4),
 ('admin_price_edit','Actualizá un precio.','Escribí el nuevo valor junto al producto.',5),
 ('admin_price_saved','Guardá el cambio.','Tocá el ícono de guardar para aplicarlo.',4),
 ('admin_new','Agregá un producto.','Completá nombre, descripción, precio y categoría.',6),
 ('admin_translation','Cargá sus traducciones.','Editá los textos en ES, EN y PT.',5),
 ('admin_attributes','Foto y etiquetas.','Configurá foto, filtros, frutos secos y disponibilidad.',6),
 ('admin_edit','Corregí los datos.','El lápiz permite editar un plato ya creado.',4),
 ('admin_deleted','Eliminá si hace falta.','La papelera pide confirmación antes de eliminar.',4),
 ('admin_settings','Ajustá el local.','WhatsApp, Wi-Fi y precio de la merienda grupal.',7),
 ('admin_reset','Restaurá los originales.','El botón de restauración pide confirmación.',6),
 ('OUTRO','','',4)]

projects={'Dorear_Reel_45s':('reel',reel),'Dorear_Tutorial_Clientes':('tutorial',tutorial),'Dorear_Guia_Equipo':('staff',staff)}
frames=ROOT/'frames';frames.mkdir(exist_ok=True);clips=ROOT/'clips';clips.mkdir(exist_ok=True)
def music(duration,path):
 # Original mellow instrumental: electric piano, soft bass and light percussion.
 sr=44100;n=int((duration+1)*sr);a=np.zeros((n,2),np.float32);rng=np.random.default_rng(24);bpm=92;beat=60/bpm
 chords=[[48,55,59,62,64],[45,52,55,59,60],[41,48,52,55,57],[43,50,53,57,59]]
 def note(start,midi,length,gain,pan=.5):
  i=int(start*sr);nn=min(int(length*sr),n-i)
  if nn<=0:return
  t=np.arange(nn)/sr;freq=440*2**((midi-69)/12);env=(1-np.exp(-t*48))*np.exp(-t*2.8/length)*np.minimum(1,(length-t)*12)
  sig=(np.sin(2*np.pi*freq*t)+.22*np.sin(2*np.pi*freq*2*t)+.08*np.sin(2*np.pi*freq*3*t))*env*gain
  a[i:i+nn,0]+=sig*np.sqrt(1-pan);a[i:i+nn,1]+=sig*np.sqrt(pan)
 for k in range(int(duration/(4*beat))+1):
  chord=chords[k%4];start=k*4*beat
  for j,m in enumerate(chord):note(start+j*.025,m+12,3.4,.028,.25+j*.12)
  for j in range(8):note(start+j*beat/2,chord[[0,2,3,4,2,3,1,2][j]]+24,1.05,.027,.25+(j%3)*.2)
  for j in [0,2]:note(start+j*beat,chord[0]-12,.95,.055,.5)
 for k in range(int(duration/beat)):
  i=int(k*beat*sr);nn=min(int(.19*sr),n-i);t=np.arange(nn)/sr
  kick=np.sin(2*np.pi*(48*t+32*(1-np.exp(-t*35))/35))*np.exp(-t*30)*.036
  if k%2==0:a[i:i+nn]+=kick[:,None]
  j=int((k+.5)*beat*sr);nh=min(int(.055*sr),n-j)
  if nh>0:
   hiss=rng.normal(0,.012,nh)*np.exp(-np.arange(nh)/sr*95);a[j:j+nh]+=hiss[:,None]
 # Tiny stereo delay for space, without external samples.
 for dt,g in [(.17,.15),(.31,.08)]:
  off=int(dt*sr);a[off:]+=a[:-off,::-1]*g
 a*=np.minimum(1,np.arange(n)/(2*sr))[:,None]*np.minimum(1,(n-np.arange(n))/(3*sr))[:,None]
 a=np.clip(a,-.95,.95);pcm=(a*32767).astype('<i2')
 with wave.open(str(path),'wb') as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(sr);w.writeframes(pcm.tobytes())

def clip(job):
 name,i,png,dur=job;target=clips/f'{name}_{i:02d}.mp4'
 if target.exists():
  r=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(target)],capture_output=True,text=True)
  try:
   if abs(float(json.loads(r.stdout)['format']['duration'])-dur)<.08:return str(target)
  except (KeyError,ValueError):pass
 vf=f"zoompan=z='1+0.008*on/{int(dur*30)}':x='iw/2-iw/zoom/2':y='ih/2-ih/zoom/2':d={int(dur*30)}:s=1080x1920:fps=30,fade=t=in:st=0:d=0.18:color=0xfaf7f0,fade=t=out:st={dur-.18}:d=0.18:color=0xfaf7f0,format=yuv420p"
 subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-i',str(png),'-vf',vf,'-t',str(dur),'-an','-c:v','libx264','-preset','veryfast','-crf','21','-threads','2','-movflags','+faststart',str(target)],check=True)
 return str(target)

jobs=[];manifest={}
for name,(kind,scenes) in projects.items():
 total=len(scenes);manifest[name]={'kind':kind,'duration':sum(x[3] for x in scenes),'scenes':[]};t=0
 for i,(shot,title,note,dur) in enumerate(scenes):
  png=frames/f'{name}_{i:02d}.png'
  im=intro(kind) if shot=='INTRO' else outro(kind) if shot=='OUTRO' else card(shot,title,note,('Carta digital' if kind=='reel' else 'Guía de uso' if kind=='tutorial' else 'Uso interno · Demo'),i+1,total)
  im.save(png);jobs.append((name,i,png,dur));manifest[name]['scenes'].append({'start':t,'end':t+dur,'shot':shot,'title':title,'instruction':note});t+=dur
(OUT/'Dorear_Guion_Escenas.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
# A distinct cover for a Reel grid and video preview.
cover=intro('reel');cover.save(OUT/'Dorear_Portada.png');
print('Frames ready:',len(jobs),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for i,result in enumerate(pool.map(clip,jobs)):
  if (i+1)%8==0:print('Clips:',i+1,'/',len(jobs),flush=True)
for name,(kind,scenes) in projects.items():
 listing=clips/f'{name}.txt';listing.write_text('\n'.join("file '"+str((clips/f'{name}_{i:02d}.mp4').resolve())+"'" for i in range(len(scenes))))
 wav=ROOT/f'{name}.wav';music(manifest[name]['duration'],wav)
 subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-y','-xerror','-f','concat','-safe','0','-i',str(listing),'-i',str(wav),'-c:v','copy','-af','volume=10dB','-c:a','aac','-b:a','160k','-shortest','-movflags','+faststart',str(OUT/(name+'.mp4'))],check=True)
 # Text cues remain editable independently of the baked-in titles.
 def tc(t):return f'{int(t)//3600:02}:{int(t)//60%60:02}:{int(t)%60:02},{int(round((t%1)*1000)):03}'
 srt=[]
 for i,s in enumerate(manifest[name]['scenes']):
  tx=(s['title']+'\n'+s['instruction']).strip() or ('Dorear · Tu carta digital' if i==0 else 'Escaneá el QR del local · @dorearcafe.ar' if kind!='staff' else 'Dorear · Guía para el equipo')
  srt.append(f"{i+1}\n{tc(s['start'])} --> {tc(s['end']-.1)}\n{tx}\n")
 (OUT/(name+'.srt')).write_text('\n'.join(srt),encoding='utf-8')
 r=subprocess.run(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(OUT/(name+'.mp4'))],capture_output=True,text=True,check=True)
 assert abs(float(json.loads(r.stdout)['format']['duration'])-manifest[name]['duration'])<.1
 print('DONE',name,manifest[name]['duration'],flush=True)
